def checkMarginAccountBalance(events, context):
    marketData = {}
    portfolioData = {}

    for event in events:
        body = event['body']
        if 'marketData' in body:
            marketData = body['marketData']
        elif 'portfolioData' in body:
            portfolioData = body['portfolioData']

    securities = portfolioData['security']
    quantities = portfolioData['quantity']
    marginAccountBalance = portfolioData['marginBalance']

    portfolioMarketValue = 0
    for idx, security in enumerate(securities):
        portfolioMarketValue += quantities[idx]*marketData[security]

    #Margin account should be atleast 25% of market value of a portfolio
    result = False
    if marginAccountBalance >= 0.25*portfolioMarketValue:
        result = True

    return {'statusCode': 200,
            'body': {'marginAccountBalance': result}}


