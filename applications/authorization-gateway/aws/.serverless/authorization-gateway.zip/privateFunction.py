def privateFunction(event, context):
    print('Entered private function successfully!')
    return {'statusCode': 200}
