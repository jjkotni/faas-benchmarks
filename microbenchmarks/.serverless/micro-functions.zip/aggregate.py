import json

def aggregateHandler(event, context):
    print("Successfully executed all parallel  functions!")

    response = {
        "statusCode": 200
    }

    return response

