import json

def inputHandler(event, context):
    response = {
        "statusCode": 200,
        "body": {"number":2}
    }

    return response

